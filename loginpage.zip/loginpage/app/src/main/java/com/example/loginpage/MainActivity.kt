package com.example.loginpage

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.loginpage.databinding.ActivityMainBinding
import android.widget.Toast





class MainActivity : AppCompatActivity() {
    lateinit var binding : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.loginbtn.setOnClickListener { onClick() }
        //admin and admin


        //admin and admin


    }

    private fun onClick() {
        val username = binding.username.text.toString();
        val password = binding.password.text.toString()
        val loginbtn = binding.loginbtn.isClickable
        if (username == "admin" && password == "admin") {
            //correct
            Toast.makeText(this@MainActivity, "LOGIN SUCCESSFUL", Toast.LENGTH_SHORT).show()
        } else  //incorrect
            Toast.makeText(this@MainActivity, "LOGIN FAILED !!!", Toast.LENGTH_SHORT).show()
    }
    }

